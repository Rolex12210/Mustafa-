#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# SKY Hash Cracker v1.1
# Coded for Mustafa (SKY) – Kali Linux

import sys
import os
import hashlib
import binascii
from PyQt5 import QtCore, QtWidgets, QtGui


# =========================
#   Hash Functions
# =========================

def hash_md5(text: str) -> str:
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def hash_sha1(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def hash_sha224(text: str) -> str:
    return hashlib.sha224(text.encode("utf-8")).hexdigest()


def hash_sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def hash_sha384(text: str) -> str:
    return hashlib.sha384(text.encode("utf-8")).hexdigest()


def hash_sha512(text: str) -> str:
    return hashlib.sha512(text.encode("utf-8")).hexdigest()


def hash_sha3_256(text: str) -> str:
    return hashlib.sha3_256(text.encode("utf-8")).hexdigest()


def hash_sha3_512(text: str) -> str:
    return hashlib.sha3_512(text.encode("utf-8")).hexdigest()


def hash_blake2b(text: str) -> str:
    return hashlib.blake2b(text.encode("utf-8")).hexdigest()


def hash_blake2s(text: str) -> str:
    return hashlib.blake2s(text.encode("utf-8")).hexdigest()


def hash_ntlm(text: str) -> str:
    """
    NTLM = MD4(UTF-16LE(password))
    """
    try:
        return hashlib.new('md4', text.encode('utf-16le')).hexdigest()
    except ValueError:
        raise RuntimeError("MD4 / NTLM not supported by this Python/OpenSSL build.")


def hash_crc32(text: str) -> str:
    """
    CRC32 يرجع 8 حروف hex
    """
    return format(binascii.crc32(text.encode("utf-8")) & 0xffffffff, "08x")


# الترتيب من الأضعف إلى الأقوى تقريبياً
HASH_TYPES = [
    "MD5",
    "SHA1",
    "SHA224",
    "SHA256",
    "SHA384",
    "SHA512",
    "SHA3_256",
    "SHA3_512",
    "BLAKE2B",
    "BLAKE2S",
    "NTLM",
    "CRC32",
]

HASH_FUNCTIONS = {
    "MD5": hash_md5,
    "SHA1": hash_sha1,
    "SHA224": hash_sha224,
    "SHA256": hash_sha256,
    "SHA384": hash_sha384,
    "SHA512": hash_sha512,
    "SHA3_256": hash_sha3_256,
    "SHA3_512": hash_sha3_512,
    "BLAKE2B": hash_blake2b,
    "BLAKE2S": hash_blake2s,
    "NTLM": hash_ntlm,
    "CRC32": hash_crc32,
}


# =========================
#   Hash Detection (Improved)
# =========================

def _is_hex(s: str) -> bool:
    try:
        int(s, 16)
        return True
    except ValueError:
        return False


def detect_hash_candidates(hash_str: str):
    """
    ترجع (best_guess, candidate_list)
    best_guess: نص واحد
    candidate_list: قائمة أنواع ممكنة مرتبة
    """
    h = hash_str.strip()
    lower = h.lower()
    length = len(h)

    candidates = []

    # أول شيء: لو hex فقط
    if _is_hex(lower):
        if length == 32:
            # ممكن MD5 أو NTLM أو CRC32 مزدوجة الخ...
            candidates.extend(["MD5", "NTLM"])
        elif length == 40:
            candidates.append("SHA1")
        elif length == 56:
            candidates.append("SHA224")
        elif length == 64:
            # ممكن SHA256 / SHA3_256 / BLAKE2S
            candidates.extend(["SHA256", "SHA3_256", "BLAKE2S"])
        elif length == 96:
            candidates.append("SHA384")
        elif length == 128:
            # SHA512 / SHA3_512 / BLAKE2B
            candidates.extend(["SHA512", "SHA3_512", "BLAKE2B"])
        elif length == 8:
            # قصير + hex → غالباً CRC32
            candidates.append("CRC32")

    # لو لحد الآن فارغ، خلي شوية أنواع شائعة كافتراضية
    if not candidates:
        candidates = ["MD5", "SHA1", "SHA256", "SHA512", "NTLM", "CRC32"]

    # تأكد كل نوع مدعوم فعلاً
    filtered = [c for c in candidates if c in HASH_FUNCTIONS]

    if not filtered:
        # fallback
        filtered = ["MD5", "SHA1", "SHA256", "SHA512"]

    best_guess = filtered[0]
    return best_guess, filtered


def detect_hash_type(hash_str: str) -> str:
    best, _ = detect_hash_candidates(hash_str)
    return best


# =========================
#   Worker Thread
# =========================

class HashCrackWorker(QtCore.QThread):
    progress = QtCore.pyqtSignal(str)
    finished = QtCore.pyqtSignal(bool, str)  # (success, message)

    def __init__(self, target_hash: str, hash_types, wordlist_path: str, parent=None, auto_mode=False):
        """
        hash_types: list of hash type strings
        auto_mode: لو True نطبع رسائل بشكل مختلف شوي
        """
        super().__init__(parent)
        self.target_hash = target_hash.strip()
        self.hash_types = hash_types if isinstance(hash_types, list) else [hash_types]
        self.wordlist_path = wordlist_path
        self.auto_mode = auto_mode
        self._stop_flag = False

    def stop(self):
        self._stop_flag = True

    def run(self):
        if not self.target_hash:
            self.finished.emit(False, "No hash value provided.")
            return

        if not os.path.isfile(self.wordlist_path):
            self.finished.emit(False, f"Wordlist not found: {self.wordlist_path}")
            return

        target_lower = self.target_hash.lower()

        self.progress.emit(f"[+] Starting cracking. Auto mode: {self.auto_mode}. Wordlist: {self.wordlist_path}")

        try:
            for htype in self.hash_types:
                if self._stop_flag:
                    self.finished.emit(False, "[!] Cracking stopped by user.")
                    return

                if htype not in HASH_FUNCTIONS:
                    self.progress.emit(f"[!] Hash type {htype} not supported, skipping.")
                    continue

                hash_func = HASH_FUNCTIONS[htype]
                self.progress.emit(f"[AUTO] Trying hash type: {htype}")

                count = 0
                # نعيد فتح الملف لكل نوع حتى نبدأ من البداية
                with open(self.wordlist_path, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        if self._stop_flag:
                            self.finished.emit(False, "[!] Cracking stopped by user.")
                            return

                        candidate = line.rstrip("\r\n")
                        if not candidate:
                            continue

                        try:
                            candidate_hash = hash_func(candidate).lower()
                        except Exception as e:
                            self.finished.emit(False, f"Error hashing with {htype}: {e}")
                            return

                        count += 1
                        if count % 5000 == 0:
                            self.progress.emit(f"[*] [{htype}] Tested: {count} passwords ... Last: {candidate}")

                        if candidate_hash == target_lower:
                            self.progress.emit(f"[+] [{htype}] Match found after {count} tries!")
                            self.finished.emit(True, f"[{htype}] Password found: {candidate}")
                            return

                self.progress.emit(f"[-] No match for type {htype}.")

            self.finished.emit(False, "[-] Password not found in any tried hash type.")

        except Exception as e:
            self.finished.emit(False, f"Error during cracking: {e}")


# =========================
#   Main Window (GUI)
# =========================

class SkyHashCracker(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("SKY Hash Cracker")
        self.setMinimumSize(900, 550)

        self.crack_worker = None

        self.init_ui()

    def init_ui(self):
        main_widget = QtWidgets.QWidget()
        self.setCentralWidget(main_widget)

        layout = QtWidgets.QVBoxLayout(main_widget)

        tabs = QtWidgets.QTabWidget()
        layout.addWidget(tabs)

        self.crack_tab = QtWidgets.QWidget()
        self.encrypt_tab = QtWidgets.QWidget()

        tabs.addTab(self.crack_tab, "🔓 Crack Hash")
        tabs.addTab(self.encrypt_tab, "🔐 Encrypt Text")

        self.init_crack_tab()
        self.init_encrypt_tab()

    # -----------------------------
    #   Crack Tab
    # -----------------------------
    def init_crack_tab(self):
        layout = QtWidgets.QVBoxLayout(self.crack_tab)

        # سطر إدخال الهاش
        hash_layout = QtWidgets.QHBoxLayout()
        self.hash_input = QtWidgets.QLineEdit()
        self.hash_input.setPlaceholderText("Enter hash to crack...")
        hash_layout.addWidget(QtWidgets.QLabel("Hash:"))
        hash_layout.addWidget(self.hash_input)

        self.detect_btn = QtWidgets.QPushButton("Detect Type")
        self.detect_btn.clicked.connect(self.on_detect_hash_type)
        hash_layout.addWidget(self.detect_btn)

        layout.addLayout(hash_layout)

        # نوع الهاش + نوع مكتشف + Auto mode
        type_layout = QtWidgets.QHBoxLayout()
        self.hash_type_combo = QtWidgets.QComboBox()
        self.hash_type_combo.addItems(HASH_TYPES)
        type_layout.addWidget(QtWidgets.QLabel("Hash Type:"))
        type_layout.addWidget(self.hash_type_combo)

        self.detected_label = QtWidgets.QLabel("Detected: Unknown")
        type_layout.addWidget(self.detected_label)

        self.auto_checkbox = QtWidgets.QCheckBox("Auto Mode (try multiple types)")
        type_layout.addWidget(self.auto_checkbox)

        layout.addLayout(type_layout)

        # اختيار ملف الورد ليست
        wl_layout = QtWidgets.QHBoxLayout()
        self.wordlist_input = QtWidgets.QLineEdit()
        self.wordlist_input.setPlaceholderText("Path to wordlist (e.g. /usr/share/wordlists/rockyou.txt)")
        wl_layout.addWidget(QtWidgets.QLabel("Wordlist:"))
        wl_layout.addWidget(self.wordlist_input)

        self.browse_btn = QtWidgets.QPushButton("Browse")
        self.browse_btn.clicked.connect(self.on_browse_wordlist)
        wl_layout.addWidget(self.browse_btn)

        layout.addLayout(wl_layout)

        # أزرار Start / Stop
        btn_layout = QtWidgets.QHBoxLayout()
        self.start_btn = QtWidgets.QPushButton("Start Cracking")
        self.start_btn.clicked.connect(self.on_start_cracking)
        btn_layout.addWidget(self.start_btn)

        self.stop_btn = QtWidgets.QPushButton("Stop")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.on_stop_cracking)
        btn_layout.addWidget(self.stop_btn)

        layout.addLayout(btn_layout)

        # صندوق اللوق / النتائج
        self.log_box = QtWidgets.QPlainTextEdit()
        self.log_box.setReadOnly(True)
        layout.addWidget(self.log_box)

    # -----------------------------
    #   Encrypt Tab
    # -----------------------------
    def init_encrypt_tab(self):
        layout = QtWidgets.QVBoxLayout(self.encrypt_tab)

        # نص المراد تشفيره
        pt_layout = QtWidgets.QHBoxLayout()
        self.plain_input = QtWidgets.QLineEdit()
        self.plain_input.setPlaceholderText("Enter text to hash...")
        pt_layout.addWidget(QtWidgets.QLabel("Text:"))
        pt_layout.addWidget(self.plain_input)
        layout.addLayout(pt_layout)

        # اختيار نوع الهاش
        enc_type_layout = QtWidgets.QHBoxLayout()
        self.enc_type_combo = QtWidgets.QComboBox()
        self.enc_type_combo.addItems(HASH_TYPES)
        enc_type_layout.addWidget(QtWidgets.QLabel("Hash Type:"))
        enc_type_layout.addWidget(self.enc_type_combo)
        layout.addLayout(enc_type_layout)

        # زر تشفير
        enc_btn_layout = QtWidgets.QHBoxLayout()
        self.encrypt_btn = QtWidgets.QPushButton("Encrypt")
        self.encrypt_btn.clicked.connect(self.on_encrypt_text)
        enc_btn_layout.addWidget(self.encrypt_btn)
        layout.addLayout(enc_btn_layout)

        # نتيجة الهاش
        self.encrypt_result = QtWidgets.QPlainTextEdit()
        self.encrypt_result.setReadOnly(True)
        layout.addWidget(self.encrypt_result)

    # =========================
    #   Crack Tab Handlers
    # =========================

    def log(self, msg: str):
        self.log_box.appendPlainText(msg)

    def on_detect_hash_type(self):
        h = self.hash_input.text().strip()
        if not h:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please enter a hash first.")
            return

        best, candidates = detect_hash_candidates(h)
        self.detected_label.setText(f"Detected: {best} (candidates: {', '.join(candidates)})")

        if best in HASH_TYPES:
            self.hash_type_combo.setCurrentText(best)
        else:
            QtWidgets.QMessageBox.information(
                self,
                "Info",
                "Could not confidently detect hash type.\nPlease select manually."
            )

    def on_browse_wordlist(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select Wordlist",
            "",
            "Text Files (*.txt);;All Files (*)"
        )
        if path:
            self.wordlist_input.setText(path)

    def on_start_cracking(self):
        target_hash = self.hash_input.text().strip()
        wordlist = self.wordlist_input.text().strip()
        selected_type = self.hash_type_combo.currentText()
        auto_mode = self.auto_checkbox.isChecked()

        if not target_hash:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please enter a hash.")
            return

        if not wordlist:
            QtWidgets.QMessageBox.warning(
                self,
                "Warning",
                "Please specify a wordlist path.\nExample: /usr/share/wordlists/rockyou.txt"
            )
            return

        # تجهيز قائمة الأنواع للتجربة
        if auto_mode:
            best, candidates = detect_hash_candidates(target_hash)
            # نضمن أن النوع المختار يضاف أيضاً
            if selected_type not in candidates:
                candidates.insert(0, selected_type)
            hash_types_to_try = []
            # نزيل التكرار مع الحفاظ على الترتيب
            for ht in candidates:
                if ht not in hash_types_to_try and ht in HASH_FUNCTIONS:
                    hash_types_to_try.append(ht)
        else:
            hash_types_to_try = [selected_type]

        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.log_box.clear()
        self.log(f"[+] Target hash: {target_hash}")
        self.log(f"[+] Selected type: {selected_type}")
        self.log(f"[+] Auto mode: {auto_mode}")
        self.log(f"[+] Types to try: {', '.join(hash_types_to_try)}")
        self.log(f"[+] Wordlist: {wordlist}")

        self.crack_worker = HashCrackWorker(
            target_hash,
            hash_types_to_try,
            wordlist,
            auto_mode=auto_mode
        )
        self.crack_worker.progress.connect(self.log)
        self.crack_worker.finished.connect(self.on_crack_finished)
        self.crack_worker.start()

    def on_stop_cracking(self):
        if self.crack_worker is not None:
            self.crack_worker.stop()
            self.log("[*] Stop requested...")

    def on_crack_finished(self, success: bool, message: str):
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.crack_worker = None

        self.log(message)
        if success:
            QtWidgets.QMessageBox.information(self, "Success", message)
        else:
            QtWidgets.QMessageBox.information(self, "Info", message)

    # =========================
    #   Encrypt Tab Handlers
    # =========================

    def on_encrypt_text(self):
        text = self.plain_input.text()
        if not text:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please enter some text to hash.")
            return

        hash_type = self.enc_type_combo.currentText()
        func = HASH_FUNCTIONS.get(hash_type)
        if func is None:
            QtWidgets.QMessageBox.warning(self, "Error", f"Unsupported hash type: {hash_type}")
            return

        try:
            h = func(text)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Error", f"Error hashing text: {e}")
            return

        self.encrypt_result.setPlainText(f"{hash_type}({text}) =\n{h}")


# =========================
#   Main
# =========================

def main():
    app = QtWidgets.QApplication(sys.argv)
    win = SkyHashCracker()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()

